!function(){function o(){n++}var n=0;console.log("before:",n),o(),console.log("after:",n)}();
